# Module 1: Kickstarter

Analyze a dataset consisting of 4,000 crowdfunding projects to discover hidden trends.
